# Branding de Quirinux para eggs (coa)

Este directorio se copia tal cual a `/etc/penguins-eggs.d/brain.d/assets/`
cuando se corre `coa wardrobe wear quirinux`, y desde ahí `eggs produce`
y `eggs sysinstall calamares` lo consumen automáticamente:

- `splash.png`: fondo de GRUB/ISOLINUX en el live. Ya soportado por coa,
  sin cambios de código (ver coa/brain.d/base.yaml.tmpl).

- `calamares/`: `branding.desc`, logo, slideshow (`show.qml` + slide1.png
  + welcome.png) y traducciones (`lang/*.qm`) de Calamares, tal como
  vienen en eggs-quirinux-config_1.4.11+q2. Requiere el patch
  feature/vendor-branding-hook en penguins-eggs.

- `calamares/finish.sh`: versión depurada de tu script fin-instalacion
  original (renombra referencias a "quirinux" en .config/.local del
  usuario real, habilita GRUB_DISABLE_OS_PROBER para dual-boot). Se
  sacaron las partes que coa ya hace por su cuenta (detección de
  $CHROOT, update-initramfs, update-grub, grub-install: todo eso ya
  corre genérico en oa-chroot-runner.sh vía debian.bash.tmpl). Requiere
  el patch feature/vendor-finish-step en penguins-eggs.

